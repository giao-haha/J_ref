# Tests for BLE monitor
